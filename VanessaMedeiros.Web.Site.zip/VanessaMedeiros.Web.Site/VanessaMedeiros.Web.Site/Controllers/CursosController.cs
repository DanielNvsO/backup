﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace VanessaMedeiros.Web.Site.Controllers
{
    public class CursosController : Controller
    {
        // GET: Cursos
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Curso_Design_Sobrancelhas_mais_Aplicacao_de_Rena()
        {
            return View();
        }

        public ActionResult Curso_Micropgmentacao_de_Sobrancelhas_Iniciante_mais_Design_Sobrancelhas()
        {
            return View();
        }

        public ActionResult Curso_Extencao_de_Cilios_3_em_1()
        {
            return View();
        }

        public ActionResult Curso_Extencao_de_Cilios_Avancado()
        {
            return View();
        }

        public ActionResult Curso_Extencao_de_Cilios_Iniciante()
        {
            return View();
        }
        public ActionResult Curso_Micropgmentacao_de_Sobrancelhas_Avançado()
        {
            return View();
        }

        public ActionResult Curso_Micropigmentacao_Labial_3_em_1()
        {
            return View();
        }
    }
}