﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace VanessaMedeiros.Web.Site.Controllers
{
    public class ServicosController : Controller
    {
        // GET: Servico
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Services_Page()
        {
            return View();
        }


        public ActionResult Servico_de_BB_Glow()
        {
            return View();
        }

        public ActionResult Servico_de_Extensao_de_Cilios()
        {
            return View();
        }

        public ActionResult Servico_de_Micropigmentacao_de_Sobrancelhas()
        {
            return View();
        }

        public ActionResult Servico_de_Micropigmentacao_Labial()
        {
            return View();
        }
            

    }
}