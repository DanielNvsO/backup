﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try { 
                Classteste1 teste1 = new Classteste1();
                Classteste2 teste2 = new Classteste2();

                teste1.metodo();
                teste2.metodo();
            }catch(Exception e)
            {
                throw e;
            }

        }
    }

    public class Classteste1
    {
        public bool metodo()
        {
            try
            {
                throw new ClassTeste1Exception();
            }
            catch (ClassTeste1Exception)
            {
                throw;
            }

            return true;
        }
    }

    public class Classteste2
    {
        public bool metodo()
        {
            try
            {
                throw new Exception("teste 2");
            }
            catch (Exception)
            {
                throw;
            }

            return true;
        }
    }

    class ClassTeste1Exception : Exception
    {
        public ClassTeste1Exception()
        : base() { }
    }




}
